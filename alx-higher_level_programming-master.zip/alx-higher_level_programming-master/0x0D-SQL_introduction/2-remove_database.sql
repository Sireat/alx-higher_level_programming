-- Deletes the database hbtn_0c_0 from my MySQL server.
DROP DATABASE IF EXISTS `hbtn_0c_0`;
