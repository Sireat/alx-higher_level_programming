-- Displays the number of records with id = 89 in the table first_table in my MySQL server.
SELECT COUNT(*)
FROM `first_table`
WHERE `id` = 89;
