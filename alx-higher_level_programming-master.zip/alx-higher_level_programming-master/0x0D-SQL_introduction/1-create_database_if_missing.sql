-- Creates the database hbtn_0c_0 in my MySQL server.
CREATE DATABASE IF NOT EXISTS `hbtn_0c_0`;
