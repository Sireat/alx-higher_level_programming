#!/usr/bin/python3
# Author - Bamidele Adefolaju

def print_last_digit(number):
    print(abs(number) % 10, end="")
    return (abs(number) % 10)
